"""Build the TIANQIONG F04 R02 three-module concept animation in Blender.

The visible machine geometry comes from the validated F04 R02 GLB, itself
round-tripped from STEP. Animation is intentionally concept-level keyframing,
not a collision, flexible-film, or dynamics simulation.
"""

from __future__ import annotations

import math
import sys
from pathlib import Path

import bpy
from mathutils import Matrix, Vector


def cli_value(flag: str, default: str | None = None) -> str | None:
    args = sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []
    if flag in args:
        i = args.index(flag)
        if i + 1 < len(args):
            return args[i + 1]
    return default


SRC_GLB = Path(cli_value("--source") or "").resolve()
OUT_BLEND = Path(cli_value("--blend") or "TIANQIONG_F04_R02_CAD_CONCEPT_V1.blend").resolve()
PREVIEW = Path(cli_value("--preview") or "TIANQIONG_review_frame.png").resolve()
OUT_MP4 = Path(cli_value("--mp4") or "TIANQIONG_F04_R02_CAD_CONCEPT_34s.mp4").resolve()
FRAMES_DIR = Path(cli_value("--frames") or "frames").resolve()

FPS = 24
END = 816  # 34 seconds at 24 fps
MODULE_PITCH = 4.25
ARM_Y = (0.350, 0.8166667, 1.2833333, 2.2166667, 2.6833333, 3.150)
JOINTS_XY = (
    (0.0, 2.8),
    (1.1495516, 2.7678901),
    (2.4455017, 2.2936397),
    (3.6328495, 1.3446375),
)


def key(obj, data_path: str, frame: int, index: int = -1) -> None:
    obj.keyframe_insert(data_path=data_path, frame=frame, index=index)


def keep_world_parent(obj: bpy.types.Object, parent: bpy.types.Object | None) -> None:
    world = obj.matrix_world.copy()
    obj.parent = parent
    obj.matrix_world = world


def set_interpolation(obj: bpy.types.Object) -> None:
    if not obj.animation_data or not obj.animation_data.action:
        return
    action = obj.animation_data.action
    # Blender 5.x layered actions no longer expose the legacy fcurves member.
    if not hasattr(action, "fcurves"):
        return
    for fcurve in action.fcurves:
        for point in fcurve.keyframe_points:
            point.interpolation = "BEZIER"
            point.handle_left_type = "AUTO_CLAMPED"
            point.handle_right_type = "AUTO_CLAMPED"


def module_name(name: str, module: int) -> str:
    if "F04_M1_" in name:
        return name.replace("F04_M1_", f"F04_M{module}_", 1)
    if name.startswith("M1_"):
        return name.replace("M1_", f"M{module}_", 1)
    if name.startswith("F04_"):
        return f"M{module}_{name}"
    return f"M{module}_{name}"


def make_empty(name: str, location: Vector, parent: bpy.types.Object | None = None) -> bpy.types.Object:
    obj = bpy.data.objects.new(name, None)
    bpy.context.scene.collection.objects.link(obj)
    obj.empty_display_type = "PLAIN_AXES"
    obj.empty_display_size = 0.16
    obj.matrix_world = Matrix.Translation(location)
    if parent:
        keep_world_parent(obj, parent)
    return obj


def add_material(name: str, color: tuple[float, float, float, float], metallic=0.0, roughness=0.4):
    mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.diffuse_color = color
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = color
        bsdf.inputs["Metallic"].default_value = metallic
        bsdf.inputs["Roughness"].default_value = roughness
        bsdf.inputs["Alpha"].default_value = color[3]
    return mat


def configure_imported_materials() -> None:
    palette = {
        "arm": ((0.10, 0.34, 0.40, 1.0), 0.60, 0.22),
        "joint": ((0.02, 0.55, 0.64, 1.0), 0.48, 0.22),
        "telescope": ((0.24, 0.55, 0.60, 1.0), 0.72, 0.18),
        "wall": ((0.20, 0.26, 0.29, 1.0), 0.58, 0.34),
        "rail": ((0.24, 0.31, 0.34, 1.0), 0.68, 0.22),
        "head": ((0.07, 0.42, 0.49, 1.0), 0.46, 0.24),
        "gate": ((1.0, 0.22, 0.035, 1.0), 0.28, 0.3),
        "band": ((0.02, 0.28, 0.34, 1.0), 0.3, 0.25),
        "roll": ((0.20, 0.25, 0.27, 1.0), 0.75, 0.18),
        "proposal": ((0.37, 0.06, 0.52, 1.0), 0.38, 0.28),
        "magnet": ((0.06, 0.07, 0.08, 1.0), 0.72, 0.18),
    }
    for mat in bpy.data.materials:
        root = mat.name.split(".")[0]
        if root == "film":
            mat.diffuse_color = (0.10, 0.74, 0.78, 0.08)
            mat.use_nodes = True
            bsdf = mat.node_tree.nodes.get("Principled BSDF")
            if bsdf:
                bsdf.inputs["Base Color"].default_value = (0.04, 0.52, 0.59, 1.0)
                bsdf.inputs["Metallic"].default_value = 0.0
                bsdf.inputs["Roughness"].default_value = 0.24
                bsdf.inputs["Alpha"].default_value = 0.08
            if hasattr(mat, "surface_render_method"):
                mat.surface_render_method = "BLENDED"
            mat.use_transparency_overlap = False
        elif root in palette:
            color, metallic, roughness = palette[root]
            mat.diffuse_color = color
            mat.use_nodes = True
            bsdf = mat.node_tree.nodes.get("Principled BSDF")
            if bsdf:
                bsdf.inputs["Base Color"].default_value = color
                bsdf.inputs["Metallic"].default_value = metallic
                bsdf.inputs["Roughness"].default_value = roughness


def import_cad() -> list[bpy.types.Object]:
    if not SRC_GLB.is_file():
        raise FileNotFoundError(SRC_GLB)
    bpy.ops.import_scene.gltf(filepath=str(SRC_GLB), import_pack_images=True)
    bpy.context.view_layer.update()
    imported = list(bpy.context.scene.objects)
    roots = [o for o in imported if o.type == "EMPTY" and not o.parent]
    meshes = [o for o in imported if o.type == "MESH"]
    for obj in meshes:
        keep_world_parent(obj, None)
    for root in roots:
        if root.name in bpy.data.objects:
            bpy.data.objects.remove(root, do_unlink=True)
    bpy.context.view_layer.update()
    return meshes


def make_modules(base_objects: list[bpy.types.Object]):
    modules: dict[int, dict[str, bpy.types.Object]] = {}
    for module in (1, 2, 3):
        zoff = (module - 1) * MODULE_PITCH
        root = make_empty(f"MODULE_{module:02d}_ROOT", Vector((0, 0, 0)))
        object_map: dict[str, bpy.types.Object] = {}
        for src in base_objects:
            obj = src if module == 1 else src.copy()
            if module != 1:
                obj.data = src.data
                bpy.context.scene.collection.objects.link(obj)
                obj.matrix_world = Matrix.Translation((0, 0, zoff)) @ src.matrix_world
            obj.name = module_name(src.name, module)
            keep_world_parent(obj, root)
            object_map[obj.name] = obj
        modules[module] = {"root": root, **object_map}

    # Move each complete CAD module into position before mechanisms deploy.
    starts = {1: Vector((0, 0, -4.2)), 2: Vector((-2.2, 0, 0)), 3: Vector((0, 0, 4.2))}
    for module, data in modules.items():
        root = data["root"]
        root.location = starts[module]
        key(root, "location", 1)
        key(root, "location", 48)
        root.location = Vector((0, 0, 0))
        key(root, "location", 104 + module * 6)
        set_interpolation(root)
    return modules


def find_values(data: dict[str, bpy.types.Object], starts: tuple[str, ...]):
    return [obj for name, obj in data.items() if isinstance(obj, bpy.types.Object) and name.startswith(starts)]


def rig_arms(modules):
    rigs: dict[tuple[int, int], list[bpy.types.Object]] = {}
    compact_deg = (-86.4, 194.5, -157.47, 194.55)
    for module, data in modules.items():
        root = data["root"]
        zoff = (module - 1) * MODULE_PITCH
        for arm in range(1, 7):
            z = zoff + ARM_Y[arm - 1]
            pivots = [make_empty(f"M{module}_A{arm:02d}_PIVOT_{i}", Vector((x, y, z)))
                      for i, (x, y) in enumerate(JOINTS_XY)]
            keep_world_parent(pivots[0], root)
            keep_world_parent(pivots[1], pivots[0])
            keep_world_parent(pivots[2], pivots[1])
            keep_world_parent(pivots[3], pivots[2])
            rigs[(module, arm)] = pivots

            arm_prefix = f"M{module}_A{arm:02d}_"
            carrier_prefix = f"F04_M{module}_A{arm:02d}_"
            groups = (
                ("link1", "joint1"),
                ("link2", "joint2"),
                ("link3", "joint3"),
                ("tel_outer", "tel_inner", "joint4", "tip"),
            )
            for seg, tokens in enumerate(groups):
                for name, obj in list(data.items()):
                    if not isinstance(obj, bpy.types.Object):
                        continue
                    if name.startswith(arm_prefix) and any(name.endswith(t) for t in tokens):
                        keep_world_parent(obj, pivots[seg])
                if seg < 3:
                    joint = seg + 1
                    for name, obj in list(data.items()):
                        if isinstance(obj, bpy.types.Object) and name.startswith(carrier_prefix + f"J{joint}_"):
                            keep_world_parent(obj, pivots[seg])

            unfold_start = 126 + (module - 1) * 10 + (arm - 1) * 5
            unfold_end = 246 + (module - 1) * 10 + (arm - 1) * 5
            for pivot, angle in zip(pivots, compact_deg):
                pivot.rotation_euler.z = math.radians(angle)
                key(pivot, "rotation_euler", 1, 2)
                key(pivot, "rotation_euler", unfold_start, 2)
                pivot.rotation_euler.z = 0.0
                key(pivot, "rotation_euler", unfold_end, 2)
                set_interpolation(pivot)
    return rigs


def rig_films(modules):
    for module, data in modules.items():
        zoff = (module - 1) * MODULE_PITCH
        pivot = make_empty(f"M{module}_F04_FILM_UNFOLD_PIVOT", Vector((4.82, 0.14, zoff + 1.75)))
        keep_world_parent(pivot, data["root"])
        film_tokens = ("F04_CONTINUOUS_SINGLE_SHEET", "F04_band", "F04_bead")
        for name, obj in data.items():
            if isinstance(obj, bpy.types.Object) and any(token in name for token in film_tokens):
                keep_world_parent(obj, pivot)
        pivot.scale = Vector((0.012, 1.0, 1.0))
        key(pivot, "scale", 1)
        key(pivot, "scale", 294 + (module - 1) * 12)
        pivot.scale = Vector((1.0, 1.0, 1.0))
        key(pivot, "scale", 398 + (module - 1) * 12)
        set_interpolation(pivot)


def animate_middle_work(modules, rigs):
    data = modules[2]
    for arm in (2, 5):
        pivots = rigs[(2, arm)]
        # A02/A05 support release: gates open, carrier heads lower.
        prefix = f"F04_M2_A{arm:02d}_"
        for name, obj in data.items():
            if not isinstance(obj, bpy.types.Object) or not name.startswith(prefix):
                continue
            base_loc = obj.location.copy()
            key(obj, "location", 430)
            if name.endswith("gateL"):
                obj.location.x -= 0.024
            elif name.endswith("gateR"):
                obj.location.x += 0.024
            key(obj, "location", 466)
            if any(t in name for t in ("_base", "_gate", "_side", "_stem", "_magnet")):
                obj.location.y -= 0.080
            key(obj, "location", 502)
            key(obj, "location", 588)
            obj.location = base_loc
            key(obj, "location", 700)
            set_interpolation(obj)

        # Retract only the moving inner telescope, terminal joint, and tip by 0.6 m.
        arm_prefix = f"M2_A{arm:02d}_"
        moving = []
        for name, obj in data.items():
            if isinstance(obj, bpy.types.Object) and name.startswith(arm_prefix) and name.endswith(("tel_inner", "joint4", "tip")):
                moving.append(obj)
        direction = Vector((math.cos(math.radians(-57.18221617)), math.sin(math.radians(-57.18221617)), 0))
        for obj in moving:
            base_loc = obj.location.copy()
            key(obj, "location", 498)
            obj.location = base_loc - direction * 0.6
            key(obj, "location", 548)
            key(obj, "location", 590)
            obj.location = base_loc
            key(obj, "location", 656)
            set_interpolation(obj)

        root_pivot = pivots[0]
        key(root_pivot, "rotation_euler", 500, 2)
        root_pivot.rotation_euler.z = math.radians(-6.0)
        key(root_pivot, "rotation_euler", 550, 2)
        key(root_pivot, "rotation_euler", 590, 2)
        root_pivot.rotation_euler.z = 0.0
        key(root_pivot, "rotation_euler", 660, 2)
        set_interpolation(root_pivot)


def add_ground_and_stage():
    ground_mat = add_material("TQ_ground", (0.025, 0.035, 0.038, 1.0), metallic=0.0, roughness=0.72)
    bpy.ops.mesh.primitive_plane_add(size=32, location=(2.0, -0.08, 6.0))
    ground = bpy.context.object
    ground.name = "TQ_GROUND"
    ground.data.materials.append(ground_mat)

    # Three subtle module pads improve scale and orientation without replacing CAD geometry.
    pad_mat = add_material("TQ_pad", (0.035, 0.12, 0.13, 1.0), metallic=0.25, roughness=0.42)
    for module in (1, 2, 3):
        bpy.ops.mesh.primitive_cube_add(location=(2.0, -0.045, (module - 1) * MODULE_PITCH + 1.75), scale=(5.8, 0.025, 1.88))
        pad = bpy.context.object
        pad.name = f"MODULE_{module:02d}_PAD"
        pad.data.materials.append(pad_mat)


def add_lighting():
    world = bpy.context.scene.world or bpy.data.worlds.new("TIANQIONG_WORLD")
    bpy.context.scene.world = world
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    bg.inputs["Color"].default_value = (0.006, 0.012, 0.017, 1.0)
    bg.inputs["Strength"].default_value = 0.48

    bpy.ops.object.light_add(type="SUN", location=(2, 8, 6))
    sun = bpy.context.object
    sun.name = "TQ_SUN"
    sun.rotation_euler = (math.radians(26), math.radians(-18), math.radians(-28))
    sun.data.energy = 2.8
    sun.data.angle = math.radians(2.0)

    bpy.ops.object.light_add(type="AREA", location=(5.5, 8.5, 6.0))
    key_light = bpy.context.object
    key_light.name = "TQ_KEY_AREA"
    key_light.data.energy = 900
    key_light.data.shape = "DISK"
    key_light.data.size = 8.0
    key_light.data.use_shadow = False
    key_light.rotation_euler = (math.radians(18), 0, math.radians(160))

    bpy.ops.object.light_add(type="AREA", location=(-3.5, 4.5, 6.0))
    fill = bpy.context.object
    fill.name = "TQ_FILL_AREA"
    fill.data.energy = 520
    fill.data.color = (0.12, 0.58, 0.72)
    fill.data.size = 7.0
    fill.data.use_shadow = False
    fill.rotation_euler = (math.radians(55), 0, math.radians(-60))

    for i, z in enumerate((1.75, 6.0, 10.25), 1):
        bpy.ops.object.light_add(type="POINT", location=(8.0, 4.5, z))
        rim = bpy.context.object
        rim.name = f"TQ_MODULE_RIM_{i}"
        rim.data.energy = 360
        rim.data.color = (0.16, 0.70, 0.82)
        rim.data.use_shadow = False


def add_camera():
    target = make_empty("CAMERA_TARGET", Vector((2.2, 1.45, 6.0)))
    bpy.ops.object.camera_add(location=(13.8, 7.0, 18.2))
    camera = bpy.context.object
    camera.name = "TIANQIONG_CAMERA"
    camera.data.lens = 48
    camera.data.sensor_width = 36
    constraint = camera.constraints.new(type="TRACK_TO")
    constraint.target = target
    constraint.track_axis = "TRACK_NEGATIVE_Z"
    # UP_X intentionally rolls the long three-module array into the 16:9 frame.
    constraint.up_axis = "UP_X"
    bpy.context.scene.camera = camera

    shots = (
        (1, (22.0, 7.2, 6.0), (2.2, 1.4, 6.0), 35),
        (120, (19.5, 6.3, 6.0), (2.2, 1.5, 6.0), 38),
        (300, (18.0, 5.5, 6.0), (2.5, 1.5, 6.0), 40),
        (420, (17.0, 4.8, 6.0), (2.8, 1.45, 6.0), 44),
        (520, (15.0, 4.0, 6.0), (3.0, 1.50, 6.0), 50),
        (620, (15.5, 4.1, 6.0), (3.0, 1.50, 6.0), 50),
        (720, (19.0, 6.0, 6.0), (2.5, 1.5, 6.0), 38),
        (816, (22.0, 7.2, 6.0), (2.3, 1.45, 6.0), 35),
    )
    for frame, cam_loc, tgt_loc, lens in shots:
        camera.location = cam_loc
        camera.data.lens = lens
        target.location = tgt_loc
        key(camera, "location", frame)
        camera.data.keyframe_insert(data_path="lens", frame=frame)
        key(target, "location", frame)
    set_interpolation(camera)
    set_interpolation(target)
    return camera


def add_title():
    title_mat = add_material("TQ_title", (0.15, 0.95, 0.96, 1.0), metallic=0.15, roughness=0.28)
    bpy.ops.object.text_add(location=(-0.65, 3.45, 0.25), rotation=(math.radians(90), 0, 0))
    title = bpy.context.object
    title.name = "TITLE_TIANQIONG"
    title.data.body = "TIANQIONG  /  F04 R02"
    title.data.align_x = "LEFT"
    title.data.size = 0.34
    title.data.extrude = 0.008
    title.data.bevel_depth = 0.003
    title.data.materials.append(title_mat)


def configure_scene():
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE"
    scene.render.resolution_x = 960
    scene.render.resolution_y = 540
    scene.render.resolution_percentage = 100
    # This Blender build has no FFmpeg output module. Render PNG frames, then
    # encode them with the locally installed FFmpeg binary.
    scene.render.image_settings.file_format = "PNG"
    scene.render.filepath = str(FRAMES_DIR / "frame_")
    scene.render.fps = FPS
    scene.render.fps_base = 1.0
    scene.frame_start = 1
    scene.frame_end = END
    scene.render.film_transparent = False
    scene.render.image_settings.color_mode = "RGB"
    scene.render.image_settings.color_depth = "8"
    scene.render.use_file_extension = True
    scene.render.use_overwrite = True
    scene.render.use_placeholder = False
    scene.render.engine = "BLENDER_EEVEE"
    if hasattr(scene, "eevee"):
        scene.eevee.taa_render_samples = 16
    scene.view_settings.look = "AgX - Medium High Contrast"
    scene.render.filepath = str(FRAMES_DIR / "frame_")
    scene["project"] = "田穹 TIANQIONG · F04 R02 true-CAD concept animation"
    scene["source_glb"] = str(SRC_GLB)
    scene["geometry_basis"] = "F04 R02: W01 + M02 six-arm + P03 + F04 continuous membrane"
    scene["module_count"] = 3
    scene["arm_count"] = 18
    scene["animation_class"] = "Concept-level keyframes; not collision/dynamics/flexible-film simulation"
    scene["intended_mp4"] = str(OUT_MP4)


def main():
    OUT_BLEND.parent.mkdir(parents=True, exist_ok=True)
    PREVIEW.parent.mkdir(parents=True, exist_ok=True)
    OUT_MP4.parent.mkdir(parents=True, exist_ok=True)
    FRAMES_DIR.mkdir(parents=True, exist_ok=True)
    bpy.ops.wm.read_factory_settings(use_empty=True)
    configure_scene()
    base = import_cad()
    configure_imported_materials()
    modules = make_modules(base)
    rigs = rig_arms(modules)
    rig_films(modules)
    animate_middle_work(modules, rigs)
    add_ground_and_stage()
    add_lighting()
    add_camera()
    add_title()
    bpy.context.scene.frame_set(520)
    bpy.context.view_layer.update()
    bpy.ops.wm.save_as_mainfile(filepath=str(OUT_BLEND), check_existing=False)

    old_path = bpy.context.scene.render.filepath
    bpy.context.scene.render.filepath = str(PREVIEW)
    bpy.ops.render.render(write_still=True)
    bpy.context.scene.render.filepath = old_path
    bpy.ops.wm.save_as_mainfile(filepath=str(OUT_BLEND), check_existing=False)
    print(f"TIANQIONG_BLEND={OUT_BLEND}")
    print(f"TIANQIONG_PREVIEW={PREVIEW}")
    print(f"TIANQIONG_MP4={OUT_MP4}")


if __name__ == "__main__":
    main()
