# 田穹 TIANQIONG · Blender 真实 CAD 概念动画工程 V1

本工程使用本机 Blender 5.2.2 LTS 实际生成和渲染。画面中的 W01 母墙、M02 六臂、P03 锚轨、F04 连续膜及承托接口来自 F04 R02 的 STEP/GLB 校验资产，不是用临时方块或替代简化几何冒充的模型。

动画属于**概念级关键帧**：用于表达三模块移动就位、18 臂展开、透明膜展开、中间模块 A02/A05 作业与复位。它不是力学、碰撞、风载、柔性膜、接触或安全控制仿真，不可据此直接制造或现场运行。

## 主要文件

- `田穹_TIANQIONG_F04_R02_真实CAD概念动画_V1.blend`：可编辑 Blender 工程，已嵌入三模块场景、关键帧、材质、灯光和镜头。
- `田穹_TIANQIONG_F04_R02_真实CAD概念动画_34s.mp4`：最终 H.264 视频。
- `田穹_TIANQIONG_F04_R02_审查帧.png`：中央模块 A02/A05 作业阶段审查帧（第 520 帧）。
- `田穹_TIANQIONG_F04_R02_总览帧_0816.png`：最终总览帧。
- `scripts/build_tianqiong_blender.py`：从 F04 R02 GLB 重建三模块 Blender 工程的脚本。
- `source_cad/01_deployed.step`：F04 R02 单模块部署总装 STEP。
- `source_cad/01_deployed.glb`：与 STEP 对应、经回读校验的米制 GLB；Blender 场景的可见机械几何来源。
- `source_cad/F04_only.step`：F04 覆盖系统 STEP。
- `source_cad/*validation*.json`、`verification_report.json`：原资产验证记录。

## 动画时间线

- 0–5 s：三套大模块移动并对正。
- 5–12 s：18 根臂按模块和臂号错峰展开。
- 12–18 s：三模块 F04 连续膜由卷收端关键帧展开。
- 18–25 s：中间模块 A02/A05 承托门打开、承托头下降、末段回缩并降低根部姿态。
- 25–30 s：短暂停留并展示作业姿态。
- 30–34 s：A02/A05 回伸、抬升、闭门，恢复支撑姿态并回到总览镜头。

## 渲染与验证

- Blender：`D:\Program Files\steam\steamapps\common\Blender\blender.exe`，版本 5.2.2 LTS。
- 渲染器：EEVEE，960×540，24 fps，816 帧。
- 编码：H.264 High Profile，`yuv420p`，MP4 fast-start。
- 实测成片：34.000 秒，816 帧；FFmpeg 全片逐帧解码返回成功。
- `.blend` 已由同一本机 Blender 重新打开并完成 1–816 帧渲染。

本机 Blender 构建不含 FFmpeg 输出模块，因此工程设置为 PNG 序列；最终 MP4 由本机 FFmpeg 8.1.1 从 `frame_0001.png` 到 `frame_0816.png` 编码。PNG 中间序列未放入交付压缩包，以避免包体无谓增大。

## 重新生成

若保持当前目录结构，可在 Blender 后台运行 `scripts/build_tianqiong_blender.py`，并把 `--source` 指向 `source_cad/01_deployed.glb`。脚本会生成三套共享原 CAD 网格数据的模块、18 臂铰接层级、F04 膜展开关键帧和 A02/A05 作业关键帧。

模型中保留的源资产限制（原腕部/支架代理交叠、膜的理想折线、未闭合的锁扣/收纳/荷载问题等）以 `source_cad/verification_report.json` 和装配关系记录为准。
